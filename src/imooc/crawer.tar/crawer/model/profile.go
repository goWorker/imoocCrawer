package model

type Profile struct {
	Name 		string
	Gender 		string
	Marriage 	string
	Age 		int
	Xingzuo		string
	Height		int
	Weight 		int
	Hukou		string
	Income		string
}
